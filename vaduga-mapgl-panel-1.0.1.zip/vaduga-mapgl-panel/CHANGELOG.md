# Changelog

## 1.0.1

- Multi layers support
- PolygonsLayer, Path (LineStrings) layer from frames datasource 
- Static GeoJson layer with FeatureCollection support from GeoJson file (url)
- Advanced thresholds processor for metrics. Set specific color for any set of parameters describing group of features.
- Points show toggle

## 1.0.0 

Initial release.
Repository has a demo provisioned dashboard with mock datasource 
